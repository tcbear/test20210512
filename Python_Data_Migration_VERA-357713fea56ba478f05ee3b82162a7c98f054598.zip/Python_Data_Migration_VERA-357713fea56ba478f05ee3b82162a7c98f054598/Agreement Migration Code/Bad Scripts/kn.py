import os

print(os.path.exists("/Users/everetmm/Desktop/Document_Conversion"))
