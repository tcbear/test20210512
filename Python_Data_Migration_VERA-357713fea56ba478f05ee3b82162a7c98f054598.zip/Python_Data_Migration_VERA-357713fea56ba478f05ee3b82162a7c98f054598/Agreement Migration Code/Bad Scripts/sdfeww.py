
import os


print (os.path.basename("try.py"))





