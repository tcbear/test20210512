
start = "\033[1m"
end = "\033[0;0m"
print ("The" + start + "text" + end + " is bold.")




